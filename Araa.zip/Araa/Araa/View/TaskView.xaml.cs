﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;


namespace Araa.View
{
    /// <summary>
    /// Interaction logic for TaskView.xaml
    /// </summary>
    public partial class TaskView : Window
    {
        private readonly string _filePath = "TextData.txt";
        private ObservableCollection<string> _tasks;

        public TaskView()
        {
            InitializeComponent();
            LoadTextFromFile();
            _tasks = new ObservableCollection<string>();
            TaskListBox.ItemsSource = _tasks;
        }

        private void LoadTextFromFile()
        {
            try
            {
                if(File.Exists(_filePath))
                {
                    txtNote.Text = File.ReadAllText(_filePath);
                }
            }
            catch(Exception ex)
            {
                txtNote.Text = "...";
            }
        }

        public ObservableCollection<string> Tasks
        {
            get { return _tasks; }
            set { _tasks = value; }
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        private void btnDraw_Click(object sender, RoutedEventArgs e)
        {
            var MainWindowView = new MainWindowView();
            this.Close();
            MainWindowView.Show();
        }

        private void btnWrite_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                File.WriteAllText(_filePath, txtNote.Text);
                MessageBox.Show("یادداشت ها ذخیره شد", "", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("یادداشت ها ذخیره نشد", "خطا", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            txtNote.Text = "";
            File.WriteAllText(_filePath, "");
            txtTaske.Text = "";
            _tasks.Clear();
        }

        private void btnPrint_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            if(printDialog.ShowDialog()==true)
            {
                string printText = "یادداشت ها" + (txtNote.Text ?? "") + "\n \n کار ها \n" + string.Join("\n", _tasks);
                TextBlock textBlock = new TextBlock { Text = printText };
                printDialog.PrintVisual(textBlock, "چاپ تسک ها");
            }
        }

        private void btnaboutas_Click(object sender, RoutedEventArgs e)
        {
            var AboutAsView = new AboutAsView();
            this.Close();
            AboutAsView.Show();
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnMaximize_Click(object sender, RoutedEventArgs e)
        {
            if (this.WindowState == WindowState.Normal)
                WindowState = WindowState.Maximized;
            else
                WindowState = WindowState.Normal;
        }

        private void btnMinimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void pnlControlBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void btnAllDone_Click(object sender, RoutedEventArgs e)
        {
            var selectedTask = TaskListBox.SelectedItem as string;
            if (selectedTask != null)
                _tasks.Remove(selectedTask);
            else
                MessageBox.Show("لطفا یک مورد از لیست را برای حذف انتخاب کنید", "خطا", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if(!string.IsNullOrWhiteSpace(txtTaske.Text))
            {
                _tasks.Add(txtTaske.Text);
                txtTaske.Text = "";
            }
            else
            {
                MessageBox.Show("لطفا متنی وارد کنید", "خطا", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void TaskListBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var selectedTask = TaskListBox.SelectedItem as string;
            if(selectedTask!=null)
            {
                int index = _tasks.IndexOf(selectedTask);
                if (index>=0 && !selectedTask.EndsWith(" ✔"))
                {
                    _tasks[index] = selectedTask + " ✔";
                }
            }          
        }
    }
}
