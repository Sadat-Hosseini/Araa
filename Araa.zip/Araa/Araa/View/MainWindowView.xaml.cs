﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;



namespace Araa.View
{
    /// <summary>
    /// Interaction logic for MainWindowView.xaml
    /// </summary>
    public partial class MainWindowView : Window
    {
        private Point _lastPoint;
        private bool _isDrawing = false;
        private Brush _currentColor = Brushes.Black;
        private double stroke = 5;
        public MainWindowView()
        {
            InitializeComponent();
            this.MaxHeight = SystemParameters.MaximizedPrimaryScreenHeight;
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void pnlControlBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void btnDraw_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void btnWrite_Click(object sender, RoutedEventArgs e)
        {
            var TaskView = new TaskView();
            this.Close();
            TaskView.Show();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter= "PNG Image (*.png)|*.png|JPEG Image (*.jpg)|*.jpg",
                Title="Save Image"
            };

            if (saveFileDialog.ShowDialog()==true)
            {
                //ذخیره طول و عرض کنوس
                Size size = new Size(MyCanvas.ActualWidth, MyCanvas.ActualHeight);

                //محاسبه اندازه کنوس
                MyCanvas.Measure(size);

                //مرتب کردن کنوس بر اساس اندازه تا اماده رندر بشه
                MyCanvas.Arrange(new Rect(size));


                //ساخت تصویر از محتویات کنوس
                RenderTargetBitmap renderBitmap = new RenderTargetBitmap(
                    (int)size.Width,   //طول و عرض به پیکسل
                    (int)size.Height,
                    96d, //کیفیت
                    96d,
                    PixelFormats.Pbgra32);  //فرمت رنگ برای کیفیت
                renderBitmap.Render(MyCanvas);   //تبدیل کنوس به این تصویر

                PngBitmapEncoder encoder = new PngBitmapEncoder();   //فرمت ذخیره
                encoder.Frames.Add(BitmapFrame.Create(renderBitmap));  //اضافه به لیست فریم


                //باز کردن جریان برای نوشتن تصویر، ایجاد تصویر، بستن جریان
                using (var fileStream = new FileStream(saveFileDialog.FileName, FileMode.Create))
                {
                    encoder.Save(fileStream);    //ذخیره تصویر در مسیر
                }
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            MyCanvas.Children.Clear();
        }

        private void btnPrint_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();

            if(printDialog.ShowDialog()==true)
            {
                //تنظیم ابعاد
                MyCanvas.Measure(new Size(printDialog.PrintableAreaWidth, printDialog.PrintableAreaHeight));
                MyCanvas.Arrange(new Rect(new Point(0, 0), MyCanvas.DesiredSize));

                //ارسال به پرینتر
                printDialog.PrintVisual(MyCanvas, "Drawing Print");
            }
        }

        private void btnaboutas_Click(object sender, RoutedEventArgs e)
        {
            var AboutAsView = new AboutAsView();
            this.Close();
            AboutAsView.Show();
        }

        private void btnMinimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnMaximize_Click(object sender, RoutedEventArgs e)
        {
            if (this.WindowState == WindowState.Normal)
                WindowState = WindowState.Maximized;
            else
                WindowState = WindowState.Normal;
        }

        private void MyCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (!_isDrawing) return;

            var newPoint = e.GetPosition(MyCanvas);
            Line line = new Line()
            {
                Stroke = _currentColor,
                X1 = _lastPoint.X,
                Y1 = _lastPoint.Y,
                X2 = newPoint.X,
                Y2 = newPoint.Y,
                StrokeThickness = stroke
            };
            MyCanvas.Children.Add(line);
            _lastPoint = newPoint;
        }

        private void MyCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            _isDrawing = true;
            _lastPoint = e.GetPosition(MyCanvas);
            
        }

        private void MyCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            _isDrawing = false;
            MyCanvas.ReleaseMouseCapture();
        }

        private void MyCanvas_MouseLeave(object sender, MouseEventArgs e)
        {
            _isDrawing = false;
        }

        private void btnBlack_Click(object sender, RoutedEventArgs e)
        {
            _currentColor = Brushes.Black;
        }

        private void btnRed_Click(object sender, RoutedEventArgs e)
        {
            _currentColor = Brushes.Red;
        }

        private void btnCyan_Click(object sender, RoutedEventArgs e)
        {
            _currentColor = Brushes.Cyan;
        }

        private void btnMore_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.ColorDialog colorDlg = new System.Windows.Forms.ColorDialog();
            if(colorDlg.ShowDialog()==System.Windows.Forms.DialogResult.OK)
            {
                //مقدار قرمز و سبز و ابی رنگ
                //تبدیل سیستم رنگی
                _currentColor = new SolidColorBrush(Color.FromRgb((byte)colorDlg.Color.R, (byte)colorDlg.Color.G, (byte)colorDlg.Color.B));               
            }
        }

        private void btnGreen_Click(object sender, RoutedEventArgs e)
        {
            _currentColor = Brushes.Green;
        }

        private void BrushSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            stroke = e.NewValue;
        }
    }
}
